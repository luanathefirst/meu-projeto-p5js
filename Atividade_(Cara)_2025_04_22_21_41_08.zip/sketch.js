function setup() {
  createCanvas(400, 400);
}
let olhoX;
let olhoY;

function draw() {
  background(217, 175, 177);
  stroke(100);
  strokeWeight(3);
  fill("#afd7d9");
  circle(320,200,100);
  circle(80,200,100);
  circle(200, 200, 300); //rosto
  fill(" #e7fefeff");
  circle(115, 150, 100); //left eye
  circle(230, 150, 100); //right eye
  line(150, 270, 250, 270); //mouth
  line(180, 160, 163, 160); ////glasses
  fill("#506886");
  triangle(200, 200, 180, 210, 160, 200); //nose
  line(90, 90, 150, 100); //eyebrows (left)
  line(195, 100, 264, 100);
  olhoX = map(mouseX, 0, 400, 68, 105);
  olhoY = map(mouseY, 0, 400, 120, 150);
  square(olhoX, olhoY, 20); //left pupil
  square(olhoX + 115, olhoY, 20); //right pupil
  if (mouseIsPressed) {
    console.log(mouseX, mouseY);
  }
}
